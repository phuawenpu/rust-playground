//! Playground for macro usage.

#![allow(dead_code, clippy::from_over_into)]

fn main() {}
